use ap;

-- Q1
SELECT DISTINCT vendor_name 
FROM vendors JOIN invoices 
ON vendors.vendor_id = invoices.vendor_id 
ORDER BY vendor_name;

SELECT DISTINCT vendor_name
from vendors
where vendor_id IN 
( select vendor_id 
from invoices)
order by vendor_name; 

-- Q2

select invoice_number, invoice_total
from 
( select invoice_number, invoice_total, payment_total, 
avg(payment_total) over() as average
from invoices
where payment_total > 0
) as it
where payment_total > average
order by invoice_total desc;

-- Q3
Select account_number, account_description
from general_ledger_accounts g
where not exists 
(select account_number
from invoice_line_items
where account_number = g.account_number)
order by account_number;

-- Q4
select vendor_name, il.invoice_id, invoice_sequence, line_item_amount
from invoice_line_items il
join 
( select i.invoice_id, vendor_name
from vendors v
join invoices i 
on v.vendor_id = i.vendor_id) t1
on t1.invoice_id = il.invoice_id
where invoice_sequence > 1
order by vendor_name, il.invoice_id, invoice_sequence;

-- Q5
select sum(indue)
from
(
SELECT vendor_id, max(invoice_total - payment_total - credit_total) as indue
FROM invoices
where invoice_total - payment_total - credit_total <> 0
group by vendor_id
) t1;

-- Q6
select v.vendor_name, t.vendor_city, t.vendor_state
from (
select vendor_city, vendor_state
from vendors
group by vendor_city, vendor_state
having count(*) = 1
) t
join vendors v
on v.vendor_city = t.vendor_city
where v.vendor_state = t.vendor_state
order by vendor_city, vendor_state;


-- Q7

SELECT v.vendor_name, i.invoice_number, i.invoice_date, i.invoice_total
FROM vendors v
JOIN invoices i 
ON v.vendor_id = i.vendor_id
WHERE i.invoice_date = (
    SELECT MIN(invoice_date)
    FROM invoices
    WHERE vendor_id = v.vendor_id
)
ORDER BY v.vendor_name;

-- Q8
select vendor_name, invoice_number, invoice_date, invoice_total
from
(select v.vendor_id, v.vendor_name ,min(invoice_date) as min
from vendors v join
invoices i
on v.vendor_id = i.vendor_id
group by vendor_id, vendor_name
)t
join invoices i
on i.vendor_id = t.vendor_id
where invoice_date = min
order by vendor_name;

-- Q9

WITH cte as (
SELECT vendor_id, max(invoice_total - payment_total - credit_total) as indue
FROM invoices
where invoice_total - payment_total - credit_total <> 0
group by vendor_id
) 
Select sum(cte.indue)
from cte;



